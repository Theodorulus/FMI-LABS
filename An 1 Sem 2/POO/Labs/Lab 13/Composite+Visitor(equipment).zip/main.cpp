#include <iostream>
#include <string>
#include <vector>

using namespace std;

// Design patterns: Creational, Structural, Behavioral

// Singleton
// class Singleton {
  // static Singleton* _sharedInstance;
  // public:
    // static init(param1, param2)
  // static Singleton* sharedInstance();
// }

// Visitor

class FloppyDisk;
class Card;

// Abstract Visitor
class Visitor {
  public:
  virtual void visitFloppyDisk(FloppyDisk &) = 0;
  virtual void visitCard(Card &) = 0;
  // virtual void visitChassis(Chassis &) = 0;
};

// Abstract Element
class Equipment {
  public:
  virtual void acceptVisitor(Visitor &visitor) = 0;
};

// Composite 
class CompoundEquipment: public Equipment {
  public:
  void addEquipment(Equipment &equipment) {
    equipments_.push_back(&equipment);
  }

  virtual void acceptVisitor(Visitor &visitor) {
    for (int i = 0; i < equipments_.size(); i++) {
      equipments_[i]->acceptVisitor(visitor);
    }
  }
  private:
  vector<Equipment*> equipments_;
};

class FloppyDisk: public Equipment {
  public:
  void acceptVisitor(Visitor &visitor) {
    visitor.visitFloppyDisk(*this);
  }
};
class Card: public Equipment {
  public:
  void acceptVisitor(Visitor &visitor) {
    visitor.visitCard(*this);
  }
};

class Chassis: public CompoundEquipment {
};

class PricingVisitor: public Visitor {
  public:
  void visitFloppyDisk(FloppyDisk &fd) {
    cout << "Visiting Floppy Disk" << endl;
    total_ += 10;
  }
  void visitCard(Card &card) {
    cout << "Visiting Card" << endl;
    total_ += 530;
  }

  double total() const { return total_; }
  private:
  double total_;
};

class InventoryVisitor: public Visitor {
  public:
  void visitFloppyDisk(FloppyDisk &fd) {
    numFloppyDisks_++;
  }
  void visitCard(Card &card) {
    numCards_++;
  }

  int numberOfFloppyDisks() const { return numFloppyDisks_; }
  int numberOfCards() const { return numCards_; }
  InventoryVisitor() : Visitor(), numFloppyDisks_(0), numCards_(0) { }
  private:
  int numFloppyDisks_;
  int numCards_;
};

int main() {
  FloppyDisk fd1;
  Card graphicsCard;
  FloppyDisk fd2;

  //
  Chassis chassis;

  chassis.addEquipment(fd1);
  chassis.addEquipment(fd2);
  chassis.addEquipment(graphicsCard);
  //

  vector<Equipment*> equipments;
  equipments.push_back(&fd1);
  equipments.push_back(&graphicsCard);
  equipments.push_back(&fd2);
  equipments.push_back(&chassis);

  PricingVisitor pricing;
  InventoryVisitor inventory;
  vector<Visitor*> visitors;
  visitors.push_back(&pricing);
  visitors.push_back(&inventory);
  for (int i = 0; i < equipments.size(); i++) {
    Equipment *equipment = equipments[i];
    // cout << "un echipament" << endl;

    // equipment->acceptVisitor(pricing);
    // equipment->acceptVisitor(inventory);
    for (int j = 0; j < visitors.size(); j++) {
      equipment->acceptVisitor(*visitors[j]);
    }
  }
  cout << pricing.total() << endl;
  cout << "numCards: " << inventory.numberOfCards() << endl;
  cout << "numFloppyDisks: " << inventory.numberOfFloppyDisks() << endl;
}

/*
// Builder

// Product
class Coffee {
  public:
  string grounds() const { return grounds_; }
  string milk() const { return milk_; }
  string topping() const { return topping_; }
  protected:
  string grounds_;
  string milk_;
  string topping_;
};

class MutableCoffee: public Coffee {
  public:
  void setTopping(string topping) { topping_ = topping;}
  void setMilk(string milk) { milk_ = milk; }
  void setGrounds(string grounds) { grounds_ = grounds; }
};

// Abstract Builder
class CoffeeBuilder {
  public:
  Coffee *finishCoffee() {
    Coffee *coffee = coffee_;
    coffee_ = NULL;
    return coffee;
  }
  void prepareNewCoffee() {
    coffee_ = new MutableCoffee;
  }
  virtual void buildGrounds() = 0;
  virtual void buildMilk() = 0;
  virtual void buildTopping() = 0;
  protected:
  MutableCoffee *coffee_;
};

class LatteCoffeeBuilder: public CoffeeBuilder {
  public:
  void buildGrounds() {
    coffee_->setGrounds("Colombia");
  }
  void buildMilk() {
    coffee_->setMilk("Vegan");
  }
  void buildTopping() {
    coffee_->setTopping("");
  }
};

class AmericanoCoffeeBuilder: public CoffeeBuilder {
  public:
  void buildGrounds() {
    coffee_->setGrounds("India");
  }
  void buildMilk() {
    coffee_->setMilk("");
  }
  void buildTopping() {
    coffee_->setTopping("");
  }
};

class Barista {
  public:
  void serveCoffee() {
    if (cb_ == NULL) { return; }
    Coffee *coffee = cb_->finishCoffee();
    // do somethign with coffee
    cout << "Coffee served" << endl;

    cb_ = NULL;
  }
  void prepareCoffee(CoffeeBuilder *cb) {
    cb_ = cb;
    cb_->prepareNewCoffee();
    cb_->buildGrounds();
    cb_->buildMilk();
    cb_->buildTopping();
  }
  private:
  CoffeeBuilder *cb_;
};

int main() {
  // Coffee coffee;
  Barista barista;
  LatteCoffeeBuilder latteCB;
  AmericanoCoffeeBuilder americanoCB;

  barista.prepareCoffee(&latteCB);
  barista.serveCoffee();
  barista.prepareCoffee(&americanoCB);
  barista.serveCoffee();
}
*/
/*

*/