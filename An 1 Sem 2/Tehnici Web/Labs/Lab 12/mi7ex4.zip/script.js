function f(elem){
	alert(elem.tagName)
}

window.onload=function(){
	
	albastru=true
	
	document.getElementById("dv").onclick=function(ev){
		f(this)
		//e.currentTarget targetul la care a ajuns cu propagarea
		//target e chiar elementul (frunza) pe care am declansat evenimentul
		console.log(ev.target)
		console.log(ev.currentTarget)
		if(ev.target==ev.currentTarget){
			// x= expresie_booleana? val_true: val_false
			this.style.backgroundColor = albastru? "red":"blue"
      albastru = !albastru
		}
	}
	
	document.getElementById("btn").onclick=function(ev){
		f(this)		
	}
	
	document.getElementById("btn2").onclick=function(ev){
		ev.stopPropagation();
		f(this)		
	}	
}

/*




*/