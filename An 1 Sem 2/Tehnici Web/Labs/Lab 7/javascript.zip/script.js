function randInt(a,b){
	return Math.trunc(a+(b-a)*Math.random()); // a ...b
}


class Culoare{  
	constructor(_r=0,_g=0,_b=0){// TO DO definiti trei parametri _r, _g, _b cu valori implicite 0
		this.r=_r;
    this.g=_g;
    this.b=_b;
	} 
	generateRandom(){
    this.r = randInt(0,255);
    this.g = randInt(0,255);
    this.b = randInt(0,255);
	}
	
	toString(){
		return "rgb("+this.r+","+this.g+","+this.b+")";//"rgb(14,100,200)"
	}
	invert(){
		return new Culoare(255-this.r,255-this.g,255-this.b);
    //TO DO calculati culoarea complementara
	}
};
/*  iRC















*/
function ransom(sir)
{
	//TO DO setati culoarea de background a body-ului la gri
	var scrisorica=document.getElementById("scrisorica");//selectati elementul cu id-ul "scrisorica"
	scrisorica.style.backgroundImage="url('http://irinaciocan.ro/imagini/hartie_veche.png')"; //setati imaginea de background ceruta in enunt <section style="background-image:url('.....')"
	for (let i=0;i<sir.length;i++) //TO DO parcurgere sir
		{

			var patt1=/\s/g;

			if(!sir[i].match(patt1))
			{
				lit=document.createElement("span");// <span>.....</span>
				scrisorica.appendChild(lit);//<section id=...><span>a</span></section>
				lit.innerHTML=sir[i] //litera de pozitia i
				c=new Culoare();
				c.generateRandom();
				lit.style.color=c.toString();
				lit.style.background=c.invert().toString();
				lit.style.fontSize=randInt(20,31)+"px"; //font-size:20px
				nr=randInt(0,2);
				lit.style.fontWeight=(nr%2==0?"bold":"normal")
				nr=randInt(0,2);
				lit.style.fontStyle=(nr%2==0?"italic":"normal") // TO DO - setare random  daca sa fie font italic sau nu (ca si la bold)
				fonturi=["Times New Roman","Comic Sans MS","Impact","Arial Black","Courier New","Lucida Console","Trebuchet MS"];
				lit.style.fontFamily=fonturi[randInt(0,fonturi.length)] //TO DO element aleator din fonturi
				lit.onclick= function(){
					console.log(this.style.color);
				} 
			}
			else
			{
				scrisorica.appendChild(document.createTextNode(" ")); // pentru spatii nu mai facem span
			}
		}
}



