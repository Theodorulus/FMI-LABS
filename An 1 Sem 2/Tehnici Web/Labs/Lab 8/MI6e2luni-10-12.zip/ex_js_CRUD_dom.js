/*
am facut pana la 4 inclusiv


*/

function randInt(a,b){
	return Math.trunc(a+(b-a)*Math.random());
}

/*
 



*/
var vPrenume=["Costica", "Gigel", "Dorel", "Maricica", "Dorica", "Gigileana", "Crinisoara", "Zoe", "Gogu", "Bob"];
var vPrefixeNume=["Bubul", "Bondar", "Dudul", "Gogul", "Zumzul"];
var vSufixeNume=["ache", "escu", "esteanu","eanu", "eschi"];
var grupe=["A", "B", "C", "D"];

//-----------------------------------------------------


function noteRandom(){
	var nrNote=randInt(1,5);
	var note=[];
	for(let i=0;i<nrNote;i++)
	{ 
		note.push(randInt(1,11));
	}
	return note;
}
/*


*/

function elevRandom(){
	return {
		prenume: vPrenume[randInt(0, vPrenume.length)], // element aleator din vPrenume
		nume: vPrefixeNume[randInt(0, vPrefixeNume.length)]+vSufixeNume[randInt(0, vSufixeNume.length)],
		grupa: grupe[randInt(0, grupe.length)],
		note: noteRandom()
	};
}
function genereazaElevi(n){
	var elevi=[];
	for(let i=0;i<n;i++){
		elevi.push(elevRandom()); // push adauga elem la finalul vectorului
	}
	console.log(elevi);
	return elevi;
}
/* 
for (let x of vector)
echivalent cu 
for (let i=0; i<vector.length; i++) {var x =vector[i]}

*/

function creeazaRand(tipCelula, vector){//returneaza un <tr>
	var tr=document.createElement("tr"); //TO DO sa se creeze un rand
  //<tr><th>nume</th><th>prenume</th>.....
	for(let x of vector){ //vector=["nume","prenume",....]
		var celula=document.createElement(tipCelula);// am th sau td 
    //<th>nume</th>  sau <td></td> 
		celula.innerHTML = x; //TO DO continutul celulei trebuie sa fie valoarea din vector <th>nume</th>
		tr.appendChild(celula);// TO DO adaugati celula in rand <tr><th>nume</th></tr>
	}
	return tr;
}

function creeazaTabel(elevi){
	if(!elevi || elevi.length==0) return;
	
	var tabel=document.createElement("table");//<table></table>
	tabel.id="tab";//<table id = "tab"></table>
	var thead=document.createElement("thead");// TO DO - creare thead
  //<table id = "tab"><thead></thead></table>
	tabel.appendChild(thead);// TO DO - adugare thead in tabel
	var rand=creeazaRand("th",Object.keys(elevi[0]));//Object.keys returneaza un vector cu numele prop obiectului-argument
	console.log("Proprietati:");console.log(Object.keys(elevi[0]));
	thead.appendChild(rand);
		
	
	var tbody=document.createElement("tbody");
	tabel.appendChild(tbody);
	for(let elev of elevi){ //TO DO vrem ca variabila elev sa aiba pe rand ca valoare fiecare element din elevi
		rand=creeazaRand("td",Object.values(elev));//["Bob","Bondarescu", "A", [1,2,3]]
    //<tr><td>Bob</td>......
		console.log("Valori:");console.log(Object.values(elev));
		tbody.appendChild(rand);
    //<tr class="A c1"
		rand.classList.add(elev.grupa);//clasa sa fie egala cu grupa elevului
		
		rand.onclick=function(e){ //e este evenimentul
			//TO DO corectati
		
      if (e.ctrlKey){ //true daca ctrl era apasat (shiftKey, altKey)
        this.remove();
        //children[1] td-ul cu numele
        afisLog(this.children[1].innerHTML   +" "+this.children[0].innerHTML+" a fost sters" );
      }
      else{
        	this.classList.toggle("selectat");// adauga daca nu exista, sterge daca exista
      }
		}
	}
	return tabel;
}

contor=0;
function afisLog(sir){
  var d_info=document.getElementById("info");
  var par = document.createElement("p");

  //new Date() - data curenta
  par.innerHTML = "["+ new Date()  +"] " + sir
  d_info.appendChild(par);
  contor++;
  d_info.title=contor;
}

/* 






*/
window.onload=function(){
	var v_elevi=genereazaElevi(10);
	document.getElementById("container_tabel").appendChild(creeazaTabel(v_elevi));
}


/*

<divid=""><p></p><table></table></....

In classlist cum stie in ce clasa il adaugdaaaaqaaaaaa???

rand.classList.add(elev.grupa);
adauga elev.grupa intr o clasa

pai da, in care clasa? :))


pai ai rand.ClassList. E lista de clase a lui rand
<tr class="aici adauga">
*/