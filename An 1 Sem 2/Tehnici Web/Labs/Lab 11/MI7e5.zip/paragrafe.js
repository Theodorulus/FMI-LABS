//MI 7 exercitiul 5


var imag=null
window.onload=function(){               
	document.getElementById("lnk").onclick=function(e){
		e.preventDefault()
		if (imag){
			imag.remove()
			imag=null
		}
		else{
			imag=document.createElement("img")
			imag.src=this.href
			document.body.appendChild(imag)
		}
	}


    
  
}  


/*                                               
                                    
 








*/