var linkuri=false; // initial sunt afisate ca text

window.onload=function(){

	document.getElementById("schimba").onclick = function(){
		var lista=document.getElementById("linkuri");
		if(!linkuri){
      for(let elem of lista.children){
        var lnk= document.createElement("a");
        lnk.href = elem.innerHTML;
        lnk.innerHTML = elem.innerHTML;
				//console.log(elem.innerHTML)
				//<li>http:....</li> acesta are un fiu care este textNode-ul "http:..." <li></li> este vid, nu are copii
				elem.replaceChild(lnk,elem.firstChild);
				//<p>abc<b>def</b>ghi</p> are trei childNodes, dar un children
      }
		}
		else{
				 for(let elem of lista.children){
					 //elem.firstElementChild este chiar un tag a
					 elem.innerHTML=elem.firstElementChild.innerHTML
				 }
			
		}
		linkuri = !linkuri;
	}

} //    
                           
                                      
                                 
 /*                              
                                 



            




*/