var dv
window.onload=function(){               
	var l=document.getElementById("lista");
  for ( let elem of lista.children) {
    elem.onclick = function() {
      this.style.color = "green" 
      var nod=this.previousElementSibling//daca this e primul element previousElementSibling va fi null
			while(nod){
				nod.style.color="red"
				nod=nod.previousElementSibling
			}
      var nod=this.nextElementSibling//daca this e primul element previousElementSibling va fi null
			while(nod){
				nod.style.color="blue"
				nod=nod.nextElementSibling
			}
    }


    
  }
}  


/*                               
                                                          
 

 









*/