//MI 7 e2

window.onkeydown=function(e){
	var tasta = e.key;
	var p = document.getElementById("litera");
	if(!p){
		p=document.createElement("span");
		p.id="litera"		
		document.body.appendChild(p);
		p.style.fontSize = "10px";

	}
	else{
    p.style.fontSize = (parseInt(p.style.fontSize) + 1) + "px";
		/*
		//presupunand ca font-size era in fisierul CSS
		stil=getComputedStyle(p)
		p.style.fontSize = (parseInt(stil.fontSize) + 1) + "px";
		*/
  }
	p.innerHTML = tasta;
}

window.onkeyup=function(e){
  document.getElementById("litera").remove();
}



/*



*/

