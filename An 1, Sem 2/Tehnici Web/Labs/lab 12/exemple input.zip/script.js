

function creeazaLi(lista, val_text){
	let li=document.createElement("li")
	lista.appendChild(li);
	li.innerHTML=val_text;
}

window.onload=function(){
console.log(1)
	document.getElementById("preia").onclick=function(){
		
		//voi crea o lista cu valorile preluate din inputuri.
		//intai verifica daca exista:
		var ul_rez=document.getElementById("rezultat");
		if(ul_rez==null){
			//daca nu exista, o creez
			ul_rez=document.createElement("ul");
			ul_rez.id="rezultat";
			document.body.appendChild(ul_rez)
		}
		//preluam datele din inputul de tip text
		creeazaLi(ul_rez, "Input text: "+document.getElementById("i_text").value);
		creeazaLi(ul_rez, "Input range: "+document.getElementById("i_text").value);
		//////////////////////////////
		var checkboxes=document.getElementsByName("i_chck");
		
		var sir="";
		for(let ch of checkboxes){
			if(ch.checked)
				sir+=ch.value+" ";
		}
		///////////////////////////////
		creeazaLi(ul_rez, "Input checkbox: "+sir);
		creeazaLi(ul_rez, "Input range: "+document.getElementById("i_text").value);
	
	alert(document.getElementById("i_text").value)
	}
}