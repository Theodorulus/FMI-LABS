#include <iostream>
#include <string>

using namespace std;

// Design patterns: Creational, Structural, Behavioral

// Singleton
// class Singleton {
  // static Singleton* _sharedInstance;
  // public:
    // static init(param1, param2)
  // static Singleton* sharedInstance();
// }

// Builder

class Coffee {
  public:
  void setTopping(string topping) { topping_ = topping;}
  void setMilk(string milk) { milk_ = milk; }
  void setGrounds(string grounds) { grounds_ = grounds; }
  private:
  string grounds_;
  string milk_;
  string topping_;
};

class CoffeeBuilder {
  public:
  Coffee *finishCoffee() {
    Coffee *coffee = coffee_;
    coffee_ = NULL;
    return coffee;
  }
  void prepareNewCoffee() {
    coffee_ = new Coffee;
  }
  virtual void buildGrounds() = 0;
  virtual void buildMilk() = 0;
  virtual void buildTopping() = 0;
  protected:
  Coffee *coffee_;
};

class LatteCoffeeBuilder: public CoffeeBuilder {
  public:
  void buildGrounds() {
    coffee_->setGrounds("Colombia");
  }
  void buildMilk() {
    coffee_->setMilk("Vegan");
  }
  void buildTopping() {
    coffee_->setTopping("");
  }
};

class AmericanoCoffeeBuilder: public CoffeeBuilder {
  public:
  void buildGrounds() {
    coffee_->setGrounds("India");
  }
  void buildMilk() {
    coffee_->setMilk("");
  }
  void buildTopping() {
    coffee_->setTopping("");
  }
};

class Barista {
  public:
  void serveCoffee() {
    if (cb_ == NULL) { return; }
    Coffee *coffee = cb_->finishCoffee();
    // do somethign with coffee
    cout << "Coffee served" << endl;
  }
  void prepareCoffee(CoffeeBuilder *cb) {
    cb_ = cb;
    cb_->prepareNewCoffee();
    cb_->buildGrounds();
    cb_->buildMilk();
    cb_->buildTopping();
  }
  private:
  CoffeeBuilder *cb_;
};

int main() {
  // Coffee coffee;
  Barista barista;
  LatteCoffeeBuilder latteCB;
  AmericanoCoffeeBuilder americanoCB;

  barista.prepareCoffee(&latteCB);
  barista.serveCoffee();
  barista.prepareCoffee(&americanoCB);
  barista.serveCoffee();
}
/*

*/